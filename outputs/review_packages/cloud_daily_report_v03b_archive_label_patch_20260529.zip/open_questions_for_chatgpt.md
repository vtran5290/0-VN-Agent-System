# Open Questions for ChatGPT — v0.3b

**Date:** 2026-05-29
**Label:** RESEARCH_ONLY_NOT_PRODUCTION
**Version:** v0.3b

1. Approve daily archive hook after EOD scan (automated vs manual script)?
2. Confirm conservative HTML labels are sufficient (no overstating weak evidence)?
3. When scan history reaches 90d, which action class to backtest first (NEW_T1 vs TRAIL_EXIT)?
4. Should `cloud_daily_report_validation.html` replace `validation_report.html` as canonical name?

## RESEARCH_ONLY_NOT_PRODUCTION
